from django.db import models

# Create your models here.
class Login(models.Model):
    username = models.CharField(max_length=20)
    password = models.CharField(max_length=20)
    role = models.CharField(max_length=20)
class Register(models.Model):
    name = models.CharField(max_length=20)
    address = models.CharField(max_length=20)
    street = models.CharField(max_length=20)
    place = models.CharField(max_length=20)
    dist = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    country = models.CharField(max_length=20)
    mob = models.IntegerField()
    email = models.EmailField()
    loginid = models.ForeignKey(Login,on_delete=models.CASCADE)
# class Villa(models.Model):
    # villaname = models.CharField(max_length=20)
    # description = models.CharField(max_length=100)
    # amt = models.IntegerField()
# class Villabooking(models.Model):
    # villaname = models.CharField(max_length=20)
    # username = models.CharField(max_length=20)
    # mob = models.IntegerField()
    # accept = models.BooleanField()
    # loginid = models.ForeignKey(Login, on_delete=models.CASCADE)
    # villaid = models.ForeignKey(Villa, on_delete=models.CASCADE)




