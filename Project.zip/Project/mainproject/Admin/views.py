from re import template

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.template import loader

from Admin.models import Register, Login

def abt(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')

def error(request):
    return render(request,'error.html')

def gallery(request):
    return render(request,'gallery.html')

def services(request):
    return render(request,'services.html')

def single(request):
    return render(request,'single.html')

def typo(request):
    return render(request,'typo.html')

def index(request):

    return render(request,'index.html')
def login(request):
    return render(request,'login.html')
def reg(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('E-mail')
        mob = request.POST.get('mobile')
        addr = request.POST.get('addr')
        dist = request.POST.get('dist')
        country = request.POST.get('country')
        city = request.POST.get('city')
        state = request.POST.get('state')
        username = request.POST.get('username')
        password = request.POST.get('password')
        cpassword = request.POST.get('cpassword')
        obj1 = Register()
        obj2 = Login()
        obj2.username = username
        obj2.password = password
        obj2.role = 'user'
        obj2.save()
        obj1.loginid = obj2
        obj1.name=name
        obj1.email=email
        obj1.address=addr
        obj1.mob=mob
        obj1.dist=dist
        obj1.country=country
        obj1.street=city
        obj1.state=state
        obj1.save()
        return render(request,'login.html')
    else:
        return render(request,'reg.html')
def signin(request):
    if request.method == 'POST':
        user = request.POST.get('uname')
        pword = request.POST.get('pass')
        if (Login.objects.filter(username=user,password=pword).exist()):
            logins = Login.objects.filter(username=user,password=pword)
            for value in logins:
                userid = value.id
                usertype=value.role
            if usertype=='user':
                Role=request.session['UserRole']='user'
                return render(request,'user/index.html')
            elif usertype=='admin':
                Role = request.session['UserRole'] = 'user'
                return render(request, 'user/index.html')
            else:
                context = {"error":"Incorrect Username"}
                return render(request, 'index.html')
        else:
            Template=loader.get_template(template("Login.html"))
            context = {"error": "Incorrect Information"}
            return  HttpResponse(Template.render(context,request))

    else:
        Template = loader.get_template(template("Login.html"))
        context = {}
        return HttpResponse(Template.render(context, request))


