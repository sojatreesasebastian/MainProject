from django.conf.urls import url

from Admin import views

urlpatterns = [
url('index',views.index,name='index'),
url('login',views.login,name='login'),
 url('reg',views.reg,name='reg'),
url('contact',views.contact,name='contact'),
url('error',views.error,name='error'),
url('gallery',views.error,name='error'),
url('abt',views.abt,name='abt'),
url('services',views.services,name='services'),
url('single',views.single,name='single'),
url('typo',views.typo,name='typo'),
]